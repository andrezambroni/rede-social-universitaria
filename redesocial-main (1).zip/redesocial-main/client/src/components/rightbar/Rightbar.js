import React from 'react'
import './rightbar.css'

export default function Rightbar() {
  return <div className="rightbar">Rightbar</div>
}
