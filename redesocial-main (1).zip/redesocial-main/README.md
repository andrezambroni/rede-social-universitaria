# redesocial-praticas-eng-software-A
 Rede social desenvolvida para matéria de práticas em engenharia de Software A. Usando Node.Js, Express, MongoDB, React, RESTFUL API.
