# app-praticas-eng-software-A
 Projeto desenvolvido para matéria de práticas A
